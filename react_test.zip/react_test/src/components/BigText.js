import React from "react";
import "./BigText.css";

const BigText = ({ children }) => {
  return <div classNam="big-text">{children}</div>;
};

export default BigText;
