import React, { Component } from "react";
import { Link, Route } from "react-router-dom";

class Abc extends Component {
  render() {
    return <div>ABC입니다</div>;
  }
}

export default Abc;
