import React from "react";
import BigText from "../components/BigText";

const Home = () => {
  return (
    <div>
      <BigText>홈</BigText>
    </div>
  );
};

export default Home;
