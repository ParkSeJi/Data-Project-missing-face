import React from "react";
// import BigText from "../components/BigText";

const About = () => {
  console.log("about");
  return (
    <div>
      소개영역입니다
      {/* <BigText>소개영역입니다.</BigText> */}
    </div>
  );
};

export default About;
