import React from "react";
import pic from "./슬라이드1.JPG";
const Home = () => {
  return (
    <div>
      <div className="container" align="center">
        <img src={pic} width="80%" alt="pic" />
      </div>
    </div>
  );
};

export default Home;
