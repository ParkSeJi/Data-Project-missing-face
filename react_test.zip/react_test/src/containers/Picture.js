import React from "react";
import BigText from "../components/BigText";

const Picture = () => {
  return (
    <div>
      <BigText>picture</BigText>
    </div>
  );
};

export default Picture;
