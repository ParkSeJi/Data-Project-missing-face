import React, { Component } from "react";
import { Link, Route } from "react-router-dom";
import UploadButtons from "./UploadButtons";
class App_Test_1 extends Component {
  render() {
    // const data = UploadButtons();
    return (
      <div>
        테스트 입니다
        <UploadButtons />
      </div>
    );
  }
}

export default App_Test_1;
